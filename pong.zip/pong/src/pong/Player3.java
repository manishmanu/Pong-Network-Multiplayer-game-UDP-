package pong;

import java.awt.Color;
import java.awt.Graphics;

public class Player3 {
	 int yVel=0,
		width=15,
		height=150,
		y=Pong.windowHeight/2-height/2,
		x=Pong.windowWidth-width-7,
		paddleSpeed = 0,
		type=0;
	GamePanel game;
	
	
	public Player3(GamePanel panel,int t){
		this.game=panel;
		this.type=t;
		this.paddleSpeed=panel.paddleSpeed;
	}
	
	public void update(){
		if(type==0){
			if(game.getBall().getX()>Pong.windowWidth/2){
				if(game.getBall().getY()<y+height/4){
					yVel = -paddleSpeed;
				}
				else if (game.getBall().getY()+game.getBall().getSize()>y+3*height/4){
					yVel = paddleSpeed;
				}
				else{
					yVel=0;
				}
			}
			else
				yVel=0;
		}
		
		if(y + yVel<=0){
			y=0;
		}
		else if(y+yVel>=Pong.windowHeight-height){
			y=Pong.windowHeight-height;
		}
		else{	
			y=y+yVel;
		}
	}
	
	public void paint(Graphics g){
		g.setColor(Color.ORANGE);
		g.fillRect(x, y, width, height);
	}
	
	public void setyVel(int v){
		if(type==1){
		yVel = v;
		}
	}
	public int getyVel(){
		return yVel;
	}
	public int getX(){
		return x;
	}
	public int getY(){
		return y;
	}
	public void setX(int p){
		x=p;
	}
	public void setY(int q){
		y = q;
	}
	public int getWidth(){
		return width;
	}
	public int getHeight(){
		return height;
	}
}
