package pong;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.sql.Date;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GameServer extends Thread{


    
    private DatagramSocket socket;
    private GamePanel game;
    String IP2 = "";
    String IP3 = "";
    String IP4 = "";  
    long p2_startTime ;
    long p2_elapsedTime = 0;
    long p3_startTime ;
    long p3_elapsedTime = 0;
    long p4_startTime ;
    long p4_elapsedTime = 0;
    boolean p2d=true;
    boolean p3d=true;
    boolean p4d=true;
    boolean startTime=true;
    DatagramPacket packet2;
    DatagramPacket packet3;
    DatagramPacket packet4;
    int humancount=0;
    int currentcount=0;
    int random;
    
    public GameServer(GamePanel game) {
        this.game = game;
         try {
//        	 random=getRandomNumber(8000,8001);
//        	 game.serverport=String.valueOf(random);
            socket = new DatagramSocket(8000);
        } catch (SocketException ex) {
            Logger.getLogger(GameClient.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
    private static int getRandomNumber(int min, int max) {
		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
    
    public void run() {
        while(true) {
            byte[] data = new byte[1024];
            DatagramPacket packet = new DatagramPacket(data, data.length);
            try {
                socket.receive(packet);
                extract(packet);
            } catch (IOException ex) {
                Logger.getLogger(GameClient.class.getName()).log(Level.SEVERE, null, ex);
            }         
        }
    }
    
    public void sendData(byte[] data,InetAddress ipAddress, int port) {
        DatagramPacket packet = new DatagramPacket(data, data.length, ipAddress, port);
        try {
            this.socket.send(packet);
        } catch (IOException ex) {
            Logger.getLogger(GameClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(!game.countdown){
        	if(startTime){
	        	p2_startTime = System.currentTimeMillis();
	        	p3_startTime = System.currentTimeMillis();
	        	p4_startTime = System.currentTimeMillis();
	        	startTime=false;
        	}
        }
        if(game.state==1&&game.disconnected_name.equals("")&&!game.countdown&&game.w.equals("")){
	        if(p2_elapsedTime<2000)
	        	p2_elapsedTime = System.currentTimeMillis() - p2_startTime;
	        else{ if(p2d&&game.p2_type==1&&game.ball.miss2>0){
	        	p2d=false;
	        	game.state=3;
	        	game.disconnected_name=game.p2_name;}}
	        if(p3_elapsedTime<2000)
	        	p3_elapsedTime = System.currentTimeMillis() - p3_startTime;
	        else{ if(p3d&&game.p3_type==1&&game.ball.miss3>0){
	        	p3d=false;
	        	game.state=3;
	        	game.disconnected_name=game.p3_name;}}
	        if(p4_elapsedTime<2000)
	        	p4_elapsedTime = System.currentTimeMillis() - p4_startTime;
	        else{ if(p4d&&game.p4_type==1&&game.ball.miss4>0){
	        	p4d=false;
	        	game.state=3;
	        	game.disconnected_name=game.p4_name;}}
        }
    }
    
    public void extract(DatagramPacket p) throws UnknownHostException{    	
    	String pack = new String(p.getData());
    	pack = pack.trim();
    	String[] data = pack.split(" ");   	
    	
    	if(data[0].equals("name")){    		    	
	    	if(game.p2_type==1 && IP2.equals("")){
	    		currentcount++;
	    		packet2 = p;
	    		IP2 = p.getAddress().toString();
	    		game.setP2name(data[1]);
	    	}	    	
	    	else if(game.p3_type==1 && IP3.equals("")){
	    		currentcount++;
	    		packet3 = p;
	    		IP3 = p.getAddress().toString();
	    		game.setP3name(data[1]);	    		
	    	}
	    	else if(game.p4_type==1 && IP4.equals("")){
	    		currentcount++;
	    		packet4 = p;
	    		IP4 = p.getAddress().toString();
	    		game.setP4name(data[1]);	    		
	    	}	    	
	    	String names = "names "+game.p1_name+" "+game.p2_name+" "+game.p3_name+" "+game.p4_name;
	    	if(!IP2.equals(""))
	    		sendData(names.getBytes(), packet2.getAddress(), packet2.getPort());
	    	if(!IP3.equals(""))
	    		sendData(names.getBytes(), packet3.getAddress(), packet3.getPort());
	    	if(!IP4.equals(""))
	    		sendData(names.getBytes(), packet4.getAddress(), packet4.getPort());
	    	try {
				sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	    	if(currentcount==humancount){	    		
	    		String go = "start "+String.valueOf(game.p2_type)+" "+String.valueOf(game.p3_type)+" "+String.valueOf(game.p4_type);
	    		if(!IP2.equals("")){
		    		sendData(go.getBytes(), packet2.getAddress(), packet2.getPort());
//		    		p2_startTime = System.currentTimeMillis();
	    		}
		    	if(!IP3.equals("")){
		    		sendData(go.getBytes(), packet3.getAddress(), packet3.getPort());
//	    		    p3_startTime = System.currentTimeMillis();
		    		}
		    	if(!IP4.equals("")){
		    		sendData(go.getBytes(), packet4.getAddress(), packet4.getPort());
//		    		p4_startTime = System.currentTimeMillis();
		    		}
		    	game.state=1;
		    	game.countdownTimeStart=System.currentTimeMillis();
	    	}
	    	
    	}
    	else if(game.state==1||game.state==3 ){
    		if(p.getAddress().toString().equals(IP2)){
    			game.player2.setxVel(Integer.valueOf(data[0]));    			
    			if(p2_elapsedTime<2000){
    				p2_startTime = System.currentTimeMillis();
    			}
    		}
    		else if(p.getAddress().toString().equals(IP3)){
    			game.player3.setyVel(Integer.valueOf(data[0]));
    			if(p3_elapsedTime<2000){
    				p3_startTime = System.currentTimeMillis();
    			}
    		}
    		else if(p.getAddress().toString().equals(IP4)){
    			game.player4.setxVel(Integer.valueOf(data[0]));
    			if(p4_elapsedTime<2000){
    				p4_startTime = System.currentTimeMillis();
    			}
    		}
    	}
    }
    
    public void sendParameters(){
    	String params = "";
    	params = params + String.valueOf(game.player1.getY()) +" ";    //player 1 details
    	params = params + String.valueOf(game.player2.getX()) +" ";    //player 2 details
    	params = params + String.valueOf(game.player3.getY()) +" ";    //player 3 details
    	params = params + String.valueOf(game.player4.getX()) +" ";    //player 4 details
    	params = params + String.valueOf(game.player1.getyVel()) +" ";    
    	params = params + String.valueOf(game.player2.getxVel()) +" ";    
    	params = params + String.valueOf(game.player3.getyVel()) +" "; 
    	params = params + String.valueOf(game.player4.getxVel()) +" "; 
    	params = params + String.valueOf(game.ball.miss1) +" ";    //Ball details
    	params = params + String.valueOf(game.ball.miss2) +" ";    
    	params = params + String.valueOf(game.ball.miss3) +" ";    
    	params = params + String.valueOf(game.ball.miss4) +" ";    
    	params = params + String.valueOf(game.ball.getX()) +" ";
    	params = params + String.valueOf(game.ball.getY()) +" ";
    	params = params + String.valueOf(game.ball.xVel) +" ";
    	params = params + String.valueOf(game.ball.yVel) +" ";
    	params = params + String.valueOf(game.state)+ " ";
    	params = params + game.disconnected_name+ " ";
    	
    	if(!IP2.equals(""))
    		sendData(params.getBytes(), packet2.getAddress(), packet2.getPort());
    	if(!IP3.equals(""))
    		sendData(params.getBytes(), packet3.getAddress(), packet3.getPort());
    	if(!IP4.equals(""))
    		sendData(params.getBytes(), packet4.getAddress(), packet4.getPort());
    }
    
    
}
    
    

