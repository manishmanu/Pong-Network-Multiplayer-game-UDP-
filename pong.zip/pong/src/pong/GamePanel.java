package pong;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.Timer;

public class GamePanel extends JPanel implements ActionListener, KeyListener, MouseListener {

	Ball ball;
	Player1 player1;
	Player2 player2;
	Player3 player3;
	Player4 player4;	
	int paddleSpeed = 6;
	int[] speedArray={2,4,6};
	GameClient socketClient;
	GameServer socketServer;
	int state = 0;
	int diff_lvl=0;
	int p2_type=0,p3_type=0,p4_type=0;
	boolean countdown = true;
	long countdownTimeStart=0;
	long countdownTime=0;
	int lan =0;
	String w = "";
	String name = "";
	String serverip = "";
	String serverport = "";
	String p1_name = "";
	String p2_name = "cpu";
	String p3_name = "cpu";
	String p4_name = "cpu";
	String disconnected_name="";

	
	public GamePanel()
	{
		//start();
		Timer time = new Timer(10, this);
		Timer time2= new Timer(5,new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				repaint();
			}	
		});
		time.start();
		time2.start();
		this.addKeyListener(this);
		this.addMouseListener(this);
		this.setFocusable(true);
		name = JOptionPane.showInputDialog("Please enter your name to start the game");
		while(name==null || name.equals("")){                              //validating name
			if(name==null){
				System.exit(1);
			}			
			name = JOptionPane.showInputDialog("Enter your name");			
		}
		p1_name = name;
	}
	
	public void startserver(){                                             //start server
			socketServer = new GameServer(this);
			socketServer.start();
			try {
				serverip = InetAddress.getLocalHost().getHostAddress();
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}						
	}
	
	public void startclient(){											   //start client
		try {
			socketClient = new GameClient(this,serverip,serverport);
			socketClient.start();
			socketClient.sendData(("name "+name).getBytes());
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}					
	}
	
	
	public void paintComponent(Graphics g){
		switch(state){
		case 0:                                                              //main menu
			g.setColor(Color.black);
			g.fillRect(0, 0, Pong.windowWidth, Pong.windowRealHeight);
			g.setColor(Color.white);
			g.setFont(new Font("Arial",1,50));
			g.drawString("PONG", 175, 75);
			
			g.drawRect(175, 200, 150, 25);//start
			
			g.drawRect(175, 250, 50, 25);//player 2
			g.drawRect(225, 250, 50, 25);
			g.drawRect(275, 250, 50, 25);
			
			g.drawRect(175, 300, 50, 25);//player 3
			g.drawRect(225, 300, 50, 25);
			g.drawRect(275, 300, 50, 25);
			
			g.drawRect(175, 350, 50, 25);//player 4
			g.drawRect(225, 350, 50, 25);
			g.drawRect(275, 350, 50, 25);
			
			g.drawRect(175, 400, 50, 25);//difficulty
			g.drawRect(225, 400, 50, 25);
			g.drawRect(275, 400, 50, 25);
			
			g.setColor(Color.MAGENTA);
			if(p2_type==0)
				g.fillRect(176, 251, 49, 24);
			else if (p2_type==1)
				g.fillRect(226, 251, 49, 24);
			else if(p2_type==2)
				g.fillRect(276, 251, 49, 24);
			
			if(p3_type==0)
				g.fillRect(176, 301, 49, 24);
			else if (p3_type==1)
				g.fillRect(226, 301, 49, 24);
			else if(p3_type==2)
				g.fillRect(276, 301, 49, 24);
			
			if(p4_type==0)
				g.fillRect(176, 351, 49, 24);
			else if (p4_type==1)
				g.fillRect(226, 351, 49, 24);
			else if(p4_type==2)
				g.fillRect(276, 351, 49, 24);
			
			if(diff_lvl==0)
				g.fillRect(176, 401, 49, 24);
			else if (diff_lvl==1)
				g.fillRect(226, 401, 49, 24);
			else if(diff_lvl==2)
				g.fillRect(276, 401, 49, 24);
			
			g.setColor(Color.white);
			g.drawRect(175, 450, 150, 25);   //join lan
			g.drawRect(175, 500, 150, 25);   //quit
			
			g.setFont(new Font("Arial",1,20));
			g.drawString("Start", 230, 220);
			
			g.setFont(new Font("Arial",1,12));
			g.drawString("Player 2", 230, 245);
			g.setFont(new Font("Arial",1,15));
			g.drawString("Cpu", 185, 268);
			g.drawString("Man", 235, 268);
			g.drawString("Wall", 285, 268);
						
			g.setFont(new Font("Arial",1,12));
			g.drawString("Player 3", 230, 295);
			g.setFont(new Font("Arial",1,15));
			g.drawString("Cpu", 185, 318);
			g.drawString("Man", 235, 318);
			g.drawString("Wall", 285, 318);
			
			g.setFont(new Font("Arial",1,12));
			g.drawString("Player 4", 230, 345);
			g.setFont(new Font("Arial",1,15));
			g.drawString("Cpu", 185, 368);
			g.drawString("Man", 235, 368);
			g.drawString("Wall", 285, 368);
			
			g.setFont(new Font("Arial",1,12));
			g.drawString("Difficulty", 230, 395);
			g.setFont(new Font("Arial",1,15));
			g.drawString("Slow", 185, 418);
			g.drawString("Med", 235, 418);
			g.drawString("Fast", 285, 418);
			
			g.setFont(new Font("Arial",1,20));
			g.drawString("Lan",235,470);
			g.drawString("Quit", 230, 520);
			
			break;
			
		case 1:			                                                          //main game screen
			w=Winner();
			if(w.equals("")){
				g.setColor(Color.BLACK);
				g.fillRect(0, 0, Pong.windowWidth, Pong.windowRealHeight);
				g.setColor(Color.WHITE);
				g.drawLine(0, Pong.windowHeight, Pong.windowWidth, Pong.windowHeight);
				g.setFont(new Font("Arial",1,18));
				
				g.setColor(Color.BLUE);
				g.drawString(p1_name,NamePosition(p1_name,100) ,Pong.windowHeight+20);
				g.drawString(MissText(ball.miss1),5+NamePosition(MissText(ball.miss1),100), Pong.windowHeight+40);
				
				if(p2_type!=2){
				g.setColor(Color.RED);
				g.drawString(p2_name,100+NamePosition(p2_name,100) ,Pong.windowHeight+20);
				g.drawString(MissText(ball.miss2), 105+NamePosition(MissText(ball.miss2),100), Pong.windowHeight+40);}
				
				if(p3_type!=2){
				g.setColor(Color.ORANGE);
				g.drawString(p3_name,200+NamePosition(p3_name,100) ,Pong.windowHeight+20);
				g.drawString(MissText(ball.miss3), 205+NamePosition(MissText(ball.miss3),100), Pong.windowHeight+40);}
				
				if(p4_type!=2){
				g.setColor(Color.YELLOW);
				g.drawString(p4_name,300+NamePosition(p4_name,100) ,Pong.windowHeight+20);
				g.drawString(MissText(ball.miss4), 305+NamePosition(MissText(ball.miss4),100), Pong.windowHeight+40);}
				
				g.setColor(Color.white);
				g.setFont(new Font("Arial",1,15));
				g.drawString("Press M",400+NamePosition("Press M",100) ,Pong.windowHeight+40);
				g.drawString("Main Menu", 400+NamePosition("Main Menu",100), Pong.windowHeight+20);
				ball.paint(g);
				if(ball.miss1>0)
					player1.paint(g);
				if(ball.miss2>0)
					player2.paint(g);
				if(ball.miss3>0)
					player3.paint(g);
				if(ball.miss4>0)
					player4.paint(g);
				if(countdown){
					if(countdownTime<3000){
						countdownTime=System.currentTimeMillis()-countdownTimeStart;
						g.setColor(Color.white);
						g.setFont(new Font("Arial",1,50));
						g.drawString(String.valueOf(3-(countdownTime/1000)),225 ,225);
					}
					else{
						countdown=false;
					}						
				}
			}
			else{
				g.setColor(Color.WHITE);
				g.setFont(new Font("Arial",1,20));
				g.drawString(w, NamePosition(w,500), 250);
			}
			break;
			
		case 2:                                                            //lan connecting screen
			g.setColor(Color.black);
			g.fillRect(0, 0, Pong.windowWidth, Pong.windowRealHeight);
			g.setColor(Color.white);
			g.setFont(new Font("Arial",1,20));	
			
			if(lan==1&&p1_name.equals(name)){
				g.drawString("Connection failed", NamePosition("Connection failed",500), 100);
			}
			else{
				g.drawString("Server ip "+serverip, NamePosition("Server ip "+serverip,500), 100);
				g.drawString("Player Blue : "+p1_name, NamePosition("Player Blue : "+p1_name,500), 150);
				
				if(p2_type!=2){
					if(p2_name.equals("cpu")&&p2_type==1)
						g.drawString("Player Red : waiting...", NamePosition("Player Blue : "+p1_name,500), 180);
					else
						g.drawString("Player Red : "+p2_name, NamePosition("Player Blue : "+p1_name,500), 180);}
				
				if(p3_type!=2){
					if(p3_name.equals("cpu")&&p3_type==1)
						g.drawString("Player Orange : waiting...", NamePosition("Player Blue : "+p1_name,500), 210);
					else
						g.drawString("Player Orange : "+p3_name, NamePosition("Player Blue : "+p1_name,500), 210);}
				
				if(p4_type!=2){
					if(p4_name.equals("cpu")&&p4_type==1)
						g.drawString("Player Yellow : waiting...", NamePosition("Player Blue : "+p1_name,500), 240);
					else
						g.drawString("Player Yellow : "+p4_name, NamePosition("Player Blue : "+p1_name,500), 240);}
			}
			g.drawRect(175, 300, 150, 25);
			g.drawString("Cancel", 220, 320);
			break;
			
		case 3:
				if(name.equals(p1_name))
					socketServer.sendParameters();
				g.setColor(Color.WHITE);
				g.setFont(new Font("Arial",1,20));
				if(disconnected_name.equals(p2_name)){
					g.drawString("Player Red : "+p2_name+" got disconnected", NamePosition("Player Blue : "+p2_name+" got disconnected",500), 150);}
				else if(disconnected_name.equals(p3_name)){
					g.drawString("Player Orange : "+p3_name+" got disconnected", NamePosition("Player Blue : "+p2_name+" got disconnected",500), 150);}
				else if(disconnected_name.equals(p4_name)){
					g.drawString("Player Yellow : "+p4_name+" got disconnected", NamePosition("Player Blue : "+p2_name+" got disconnected",500), 150);}
				
				if(name.equals(p1_name)){
					g.drawString("What do you want to replace it with?", NamePosition("What do you want to replace it with?",500), 200);
					g.drawRect(175, 250, 50, 25);
					g.drawRect(275, 250, 50, 25);
					g.setFont(new Font("Arial",1,15));
					g.drawString("Cpu", 185, 268);
					g.drawString("Wall", 285, 268);}
			
			
		}
	}
	
	public void update(){
		if(state==1){
		ball.findCollision(player1);
		ball.findCollision(player2);
		ball.findCollision(player3);
		ball.findCollision(player4);
		if(w.equals(""))
			ball.update();
		if(ball.miss1>0)
			player1.update();
		if(ball.miss2>0)
			player2.update();
		if(ball.miss3>0)
			player3.update();
		if(ball.miss4>0)
			player4.update();}
		
		if(p2_type==1||p3_type==1||p4_type==1){
			if(name.equals(p2_name)&&p2_type==1){
				String clientdata = String.valueOf(player2.getxVel());
				socketClient.sendData(clientdata.getBytes());
			}
			else if(name.equals(p3_name)&&p3_type==1){
				String clientdata = String.valueOf(player3.getyVel());
				socketClient.sendData(clientdata.getBytes());
			}
			else if(name.equals(p4_name)&&p4_type==1){
				String clientdata = String.valueOf(player4.getxVel());
				socketClient.sendData(clientdata.getBytes());
			}
			else if(name.equals(p1_name)){                                  //server sends data to the clients
				socketServer.sendParameters();
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {		                    //repeating function
		if(!countdown)
			if(state==1||state==3)
				update();
//		repaint();	
	}

	public Ball getBall(){
		return ball;
	}
	
	public int  NamePosition(String s,int pos){
		int l;
		l = s.length()*5;
		l = pos/2-l;
		return l;
	}
	
	public String MissText(int m){
		if(m<=0){
			return "lost";
		}
		else{
			return String.valueOf(m);
		}		
	}
	
	public String Winner(){
		if(ball.miss1>0&&ball.miss2<=0&&ball.miss3<=0&&ball.miss4<=0)
			return "!!Player Blue wins!!";
		else if(ball.miss1<=0&&ball.miss2>0&&ball.miss3<=0&&ball.miss4<=0)
			return "!!Player Red wins!!";
		else if(ball.miss1<=0&&ball.miss2<=0&&ball.miss3>0&&ball.miss4<=0)
			return "!!Player Orange wins!!";
		else if(ball.miss1<=0&&ball.miss2<=0&&ball.miss3<=0&&ball.miss4>0)
			return "!!Player Yellow wins!!";
		else
			return "";
	}
	
//################################################################################### keyboard
	@Override
	public void keyPressed(KeyEvent arg0) {
		int k = arg0.getKeyCode();
		if(name.equals(p1_name)){
			if (k==KeyEvent.VK_UP){
				player1.setyVel(-paddleSpeed);
				if(player1.y==0)
					player1.setyVel(0);
			}
			if (k==KeyEvent.VK_DOWN){
				player1.setyVel(paddleSpeed);
				if(player1.y==Pong.windowHeight-player1.height)
					player1.setyVel(0);
			}
		}
		else if(name.equals(p2_name)){
			if (k==KeyEvent.VK_LEFT){
				player2.setxVel(-paddleSpeed);
				if(player2.x==0)
					player2.setxVel(0);
			}
			if (k==KeyEvent.VK_RIGHT){
				player2.setxVel(paddleSpeed);
				if(player2.y==Pong.windowWidth-player2.width-7)
					player2.setxVel(0);
			}
		}
		else if(name.equals(p3_name)){
			if (k==KeyEvent.VK_UP){
				player3.setyVel(-paddleSpeed);
				if(player3.y==0)
					player3.setyVel(0);
			}
			if (k==KeyEvent.VK_DOWN){
				player3.setyVel(paddleSpeed);
				if(player3.y==Pong.windowHeight-player3.height)
					player3.setyVel(0);
			}
		}
		else if(name.equals(p4_name)){
			if (k==KeyEvent.VK_LEFT){
				player4.setxVel(-paddleSpeed);
				if(player4.x==0)
					player4.setxVel(0);
			}
			if (k==KeyEvent.VK_RIGHT){
				player4.setxVel(paddleSpeed);
				if(player4.y==Pong.windowWidth-player4.width-7)
					player4.setxVel(0);
			}
		}
		if(k==KeyEvent.VK_M){
			if(state==1||state==3)
				initialize();
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		if(arg0.getKeyCode()==KeyEvent.VK_UP||arg0.getKeyCode()==KeyEvent.VK_DOWN){
			player1.setyVel(0);
			player3.setyVel(0);}
		if(arg0.getKeyCode()==KeyEvent.VK_LEFT||arg0.getKeyCode()==KeyEvent.VK_RIGHT){
			player2.setxVel(0);
			player4.setxVel(0);}
	}
	
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	//####################################################################################### mouse
	@Override
	public void mousePressed(MouseEvent arg0) {
		int mx = arg0.getX();
		int my = arg0.getY();
		
		if(state==0){
			if(mx>175&&mx<325){
				if(my>200&&my<225){                         //when start button is clicked players are initialized	
					paddleSpeed = speedArray[diff_lvl];
					ball = new Ball();
					player1 = new Player1(this,1);
					if(p2_type!=2)
						player2 = new Player2(this,p2_type);
					else{
						player2 = new Player2(this,1);
						ball.miss2=0;}
					if(p3_type!=2)
						player3 = new Player3(this,p3_type);
					else{
						player3 = new Player3(this,1);
						ball.miss3=0;}
					if(p4_type!=2)
						player4 = new Player4(this,p4_type);
					else{
						player4 = new Player4(this,1);
						ball.miss4=0;}
					
					if(p2_type==2&&p3_type==2&&p4_type==2){
						
					}
					else if(p2_type==1||p3_type==1||p4_type==1){
						 
						if(socketServer==null)
							startserver();
						if(p2_type==1){
				        	socketServer.humancount++;
				        }
				        if(p3_type==1){
				        	socketServer.humancount++;
				        }
				        if(p4_type==1){
				        	socketServer.humancount++;
				        }
						state=2;					
					}
					else{
						countdownTimeStart=System.currentTimeMillis();
						state=1;
					}
				}
				else if(my>250&&my<275){          //player 2 type
					if(mx<225){
						p2_type=0;
					}
					else if(mx>225&&mx<275){
						p2_type=1;
					}
					else{
						p2_type=2;
					}
				}
				else if(my>300&&my<325){			//player 3 type
					if(mx<225){
						p3_type=0;
					}
					else if(mx>225&&mx<275){
						p3_type=1;
					}
					else{
						p3_type=2;
					}
				}
				else if(my>350&&my<375){			//player 4 type
					if(mx<225){
						p4_type=0;
					}
					else if(mx>225&&mx<275){
						p4_type=1;
					}
					else{
						p4_type=2;
					}
				}
				else if(my>400&&my<425){			// difficulty
					if(mx<225){
						diff_lvl=0;
					}
					else if(mx>225&&mx<275){
						diff_lvl=1;
					}
					else{
						diff_lvl=2;
					}
				}
				else if (my>450&&my<475){      //client connecting to lan
					lan=1;
					serverip = JOptionPane.showInputDialog("Enter server's ip address: ");
					if(serverip!=null){
//						serverport = JOptionPane.showInputDialog("Enter server's port: ");
//						if(serverport!=null){
							startclient();
							state=2;
//							}
						}
				}
				else if(my>500&&my<525){       //exit
					System.exit(1);
				}
			}
		}
		else if(state==2){
			if(mx>175&&mx<325){
				if(my>300&&my<325){
					//kill server
					//kill client
					initialize();
				}
			}	
		}
		else if(state==3){
			if(my>250&&my<275){         						 //player disconnected
				if(mx>175&&mx<225){								//cpu
					if(disconnected_name.equals(p2_name)){
						player2.type=0;
					}
					else if(disconnected_name.equals(p3_name)){
						player3.type=0;
					}
					else if(disconnected_name.equals(p4_name)){
						player4.type=0;
					}
					state=1;
					disconnected_name="";
				}
				else if(mx>275&&mx<325){							//wall
					if(disconnected_name.equals(p2_name)){
						player2.type=2;
						ball.miss2=0;
					}
					else if(disconnected_name.equals(p3_name)){
						player3.type=2;
						ball.miss3=0;
					}
					else if(disconnected_name.equals(p4_name)){
						player4.type=2;
						ball.miss4=0;
					}
					state=1;
					disconnected_name="";
				}
			}
		}
	}

	

	
	public void setP1name(String s){
		p1_name = s;
	}
	
	public void setP2name(String s){
		p2_name = s;
	}
	
	public void setP3name(String s){
		p3_name = s;
	}
	
	public void setP4name(String s){
		p4_name = s;
	}
	
	public void setPaddlespeed(int speed){
		paddleSpeed=speed;
	}
	
	public void initialize(){                                       // on pressing m goes back to main menu screen
		countdown = true;
		countdownTimeStart=0;
		countdownTime=0;
		state = 0;
		w = "";
		diff_lvl=0;
		lan =0;
		
		p2_type=0;
		p3_type=0;
		p4_type=0;
				
		p1_name = name;
		p2_name = "cpu";
		p3_name = "cpu";
		p4_name = "cpu";
		disconnected_name="";
		
		if(socketClient!=null&&socketClient.isAlive()){
			socketClient.stop();
		}
		if(socketServer!=null&&socketServer.isAlive()){
			socketServer.IP2 = "";
			socketServer.IP3 = "";
			socketServer.IP4 = "";  
			socketServer.p2_elapsedTime = 0;
		    socketServer.p3_elapsedTime = 0;
		    socketServer.p4_elapsedTime = 0;
		    socketServer.p2d=true;
		    socketServer.p3d=true;
		    socketServer.p4d=true;
		    socketServer.packet2=null;
		    socketServer.packet3=null;
		    socketServer.packet4=null;
		    socketServer.humancount=0;
		    socketServer.currentcount=0;
		    socketServer.startTime=true;
		}
	}
	

}
