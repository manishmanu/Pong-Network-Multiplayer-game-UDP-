package pong;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Ball {
	int xVel=getRandomNumber(1,2);
	int yVel=getRandomNumber(1,2);
	int size = 20;
	int x=(Pong.windowWidth-7)/2-size;
	int y=(Pong.windowHeight)/2-size;
	int miss1=3,miss2=3,miss3=3,miss4=3;
	
	private static int getRandomNumber(int min, int max) {
		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
	
	public void update(){
		if(xVel==0){
			xVel++;
		}
		if(yVel==0){
			yVel++;
		}
		x = x + xVel;
		y = y + yVel;
		
		if(x<0){
			xVel = -xVel;
			miss1--;
		}
		else if(x+size>Pong.windowWidth-7){
			xVel = -xVel;
			miss3--;
		}
		if(y<0){
			yVel = -yVel;
			miss2--;
		}
		else if (y+size>Pong.windowHeight){
			yVel = -yVel;
			miss4--;
		}
	}
	
	public void paint(Graphics g){
		g.setColor(Color.WHITE);
		g.fillOval(x, y, size, size);
	}
	
	public int getX(){
		return x;
	}
	public int getY(){
		return y;
	}
	public void setX(int p){
		x=p;
	}
	public void setY(int q){
		y = q;
	}
	public void setMiss1(int m1){
		miss1 = m1;
	}
	public void setMiss2(int m2){
		miss2 = m2;
	}
	public void setMiss3(int m3){
		miss3 = m3;
	}
	public void setMiss4(int m4){
		miss4 = m4;
	}
	public int getSize(){
		return size;
	}
	
	public void findCollision(Player1 p){//check the collision of ball with the paddle1
		if(x>p.getX()&&x<p.getX()+p.getWidth()&&miss1>0){
			if(xVel<0){
				if(y>p.getY()&&y<p.getY()+p.getHeight()){
					xVel = -xVel;
					yVel = yVel+p.getyVel()/2;
				}
			}
		}				
	}
	
	public void findCollision(Player2 p){//check the collision of ball with the paddle2
		if(y>p.getY()&&y<p.getY()+p.getHeight()&&miss2>0){
			if(yVel<0){
				if(x>p.getX()&&x<p.getX()+p.getWidth()){
					yVel = -yVel;
					xVel = xVel+p.getxVel()/2;
				}
			}
		}				
	}
	
	public void findCollision(Player3 p){//check the collision of ball with the paddle3
		if(x+size>p.getX()&&x+size<p.getX()+p.getWidth()&&miss3>0){
			if(xVel>0){
				if(y>p.getY()&&y<p.getY()+p.getHeight()){
					xVel = -xVel;
					yVel = yVel+p.getyVel()/2;
				}
			}
		}				
	}
	
	public void findCollision(Player4 p){//check the collision of ball with the paddle4
		if(y+size>p.getY()&&y+size<p.getY()+p.getHeight()&&miss4>0){
			if(yVel>0){
				if(x>p.getX()&&x<p.getX()+p.getWidth()){
					yVel = -yVel;
					xVel = xVel+p.getxVel()/2;
				}
			}
		}				
	}
	
}
