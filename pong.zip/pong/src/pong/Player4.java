package pong;

import java.awt.Color;
import java.awt.Graphics;

public class Player4 {
	 int xVel=0,
		width=150,
		height=15,
		x=Pong.windowWidth/2-width/2,
		y=Pong.windowHeight-height,
		paddleSpeed = 0,
		type=0;
	GamePanel game;
	
	
	public Player4(GamePanel panel,int t){
		this.game=panel;
		this.type=t;
		this.paddleSpeed=panel.paddleSpeed;
	}
	
	public void update(){
		if(type==0){
			if(game.getBall().getY()>Pong.windowHeight/2){
				if(game.getBall().getX()<x+width/4){
					xVel = -paddleSpeed;
				}
				else if (game.getBall().getX()+game.getBall().getSize()>x+3*width/4){
					xVel = paddleSpeed;
				}
				else{
					xVel=0;
				}
			}
			else
				xVel=0;
		}
		
		if(x + xVel<=0){
			x=0;
		}
		else if(x+xVel>=Pong.windowWidth-width-7){
			x=Pong.windowWidth-width-7;
		}
		else{	
			x=x+xVel;
		}
	}
	
	public void paint(Graphics g){
		g.setColor(Color.YELLOW);
		g.fillRect(x, y, width, height);
	}
	
	public void setxVel(int v){
		if(type==1){
		xVel = v;
		}
	}
	public int getxVel(){
		return xVel;
	}
	public int getX(){
		return x;
	}
	public int getY(){
		return y;
	}
	public void setX(int p){
		x=p;
	}
	public void setY(int q){
		y = q;
	}
	public int getWidth(){
		return width;
	}
	public int getHeight(){
		return height;
	}
}
