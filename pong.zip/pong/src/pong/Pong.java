package pong;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Pong extends JFrame {
	final static int windowWidth = 507;
	final static int windowRealHeight = 583;
	final static int windowHeight = 500;
	public Pong()
	{
		setSize(windowWidth,windowRealHeight);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		add(new GamePanel());
		setVisible(true);
	}
	
	public static void main(String[] args){
		new Pong();
	}
}
