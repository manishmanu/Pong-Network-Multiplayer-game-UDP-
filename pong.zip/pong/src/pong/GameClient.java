package pong;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class GameClient extends Thread {
    private InetAddress ipAddress;
    private DatagramSocket socket;
    private GamePanel game;
    int serverport;
    public GameClient(GamePanel game, String ipAddress,String sp) throws UnknownHostException {
        this.game = game;
        try {
            this.socket = new DatagramSocket();
        } catch (SocketException ex) {
            Logger.getLogger(GameClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.ipAddress = InetAddress.getByName(ipAddress);
//        this.serverport = Integer.valueOf(sp);
    }
    
    public void run() {
    
        while(true) {
            byte[] data = new byte[1024];
            DatagramPacket packet = new DatagramPacket(data, data.length);
            try {
                socket.receive(packet);
                extract(packet);
            } catch (IOException ex) {
                Logger.getLogger(GameClient.class.getName()).log(Level.SEVERE, null, ex);
            }
            //check            
        }
    }
    
    public void sendData(byte[] data) {
        DatagramPacket packet = new DatagramPacket(data, data.length, ipAddress,8000);
        try {
            socket.send(packet);
        } catch (IOException ex) {
            Logger.getLogger(GameClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void extract(DatagramPacket p) throws UnknownHostException{    	
    	String pack = new String(p.getData());
    	pack = pack.trim();
    	String[] data;
    	data = pack.split(" ");
    	if(data[0].equals("names")){
    			    	
	    	game.setP1name(data[1]);
	    	game.setP2name(data[2]);
	    	game.setP3name(data[3]);
	    	game.setP4name(data[4]);
    	}
    	else if(data[0].equals("start")){
    		game.ball = new Ball();
    		game.p2_type = Integer.valueOf(data[1]);
    		game.p3_type = Integer.valueOf(data[2]);
    		game.p4_type = Integer.valueOf(data[3]);
    		game.player1 = new Player1(game,1);
    		game.player2 = new Player2(game,Integer.valueOf(data[1]));
    		game.player3 = new Player3(game,Integer.valueOf(data[2]));
    		game.player4 = new Player4(game,Integer.valueOf(data[3]));   		
    		game.state=1;
    		game.countdownTimeStart=System.currentTimeMillis();
    	}
    	else if(game.state==1){
    		game.player1.setyVel(Integer.valueOf(data[4]));
    		if(!game.name.equals(game.p2_name))
    			game.player2.setxVel(Integer.valueOf(data[5]));
    		if(!game.name.equals(game.p3_name))
    			game.player3.setyVel(Integer.valueOf(data[6]));
    		if(!game.name.equals(game.p4_name))
    			game.player4.setxVel(Integer.valueOf(data[7]));
    		game.ball.setMiss1(Integer.valueOf(data[8]));
    		game.ball.setMiss2(Integer.valueOf(data[9]));
    		game.ball.setMiss3(Integer.valueOf(data[10]));
    		game.ball.setMiss4(Integer.valueOf(data[11]));
    		int temp_x=Integer.valueOf(data[12]);
    		int temp_y=Integer.valueOf(data[13]);
    		if(temp_x<50||temp_x>450||temp_y<50||temp_y>450){
    			game.ball.setX(temp_x);
    			game.ball.setY(temp_y);
    			game.ball.xVel = Integer.valueOf(data[14]);
    			game.ball.yVel = Integer.valueOf(data[15]);
    			game.player1.setY(Integer.valueOf(data[0])); 
        		if(!game.name.equals(game.p2_name))
        			game.player2.setX(Integer.valueOf(data[1]));
        		if(!game.name.equals(game.p3_name))
        			game.player3.setY(Integer.valueOf(data[2]));
        		if(!game.name.equals(game.p4_name))
        			game.player4.setX(Integer.valueOf(data[3]));
    		}
    		
    		game.state=Integer.valueOf(data[16]);
    		if(data.length==18)
    			game.disconnected_name=data[17];
    	}
    	else if(game.state==3)
    		game.state=Integer.valueOf(data[16]);
    }
    
}

